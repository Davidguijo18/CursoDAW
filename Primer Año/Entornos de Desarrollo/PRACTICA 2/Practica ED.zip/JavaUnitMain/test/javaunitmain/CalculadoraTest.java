/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package javaunitmain;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author D
 */
public class CalculadoraTest {
    
    public CalculadoraTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testSuma() {
        Calculadora calcu = new Calculadora(20,10);
        int result = calcu.suma();
        assertEquals(30, result);
    }

    @Test
    public void testResta() {
        Calculadora calcu = new Calculadora(20,10);
        int result = calcu.resta();
        assertEquals(10, result);
    }
    
    @Test
    public void testMultiplicacion() {
        Calculadora calcu = new Calculadora(20,10);
        int result = calcu.multiplicacion();
        assertEquals(200, result);
    }

    @Test
    public void testDividir() {
        Calculadora calcu = new Calculadora();
        int result = calcu.dividir();
        assertEquals(2, result);
    }
    
}

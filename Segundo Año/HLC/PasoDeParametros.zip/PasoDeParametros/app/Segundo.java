public class Segundo{
}

package com.example.listafestivales;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etPais, etFestivales;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etFestivales = findViewById(R.id.festivales);
        SharedPreferences preferences = getSharedPreferences("datos", Context.MODE_PRIVATE);
        etFestivales.setText(preferences.getString("text", ""));
    }

    public void guardar(View view) {
        SharedPreferences preferencias = getSharedPreferences("datos",Context.MODE_PRIVATE);
        SharedPreferences.Editor obj_editor = preferencias.edit();
        obj_editor.putString("text",etFestivales.getText().toString());
        obj_editor.commit();
    }

    public void buscar(View view) {

        Intent siguiente = new Intent(this,MainActivity2.class);
        siguiente.putExtra("dato",etFestivales.getText().toString());
        startActivity(siguiente);
    }
}
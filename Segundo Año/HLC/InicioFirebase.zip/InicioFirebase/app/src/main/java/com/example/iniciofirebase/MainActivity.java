package com.example.iniciofirebase;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth auth;
    EditText id,nombre,ubicacion,inicio,fin;
    FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        id = findViewById(R.id.idMercado);
        nombre = findViewById(R.id.nombreMercado);
        ubicacion = findViewById(R.id.ubiMercado);
        inicio = findViewById(R.id.inicioMercado);
        fin = findViewById(R.id.finMercado);
    }

    public void insertarMercado(View view){
        String idMercado = id.getText().toString().trim();
        String nombreMercado = nombre.getText().toString().trim();
        String ubiMercado = ubicacion.getText().toString().trim();
        String inicioMercado = inicio.getText().toString().trim();
        String finMercado = fin.getText().toString().trim();

        agregarMercado(idMercado,nombreMercado,ubiMercado,inicioMercado,finMercado);
    }

    private void agregarMercado(String idMercado, String nombreMercado, String ubiMercado, String inicioMercado, String finMercado){
        Map<String,Object> mapa = new HashMap<>();
        mapa.put("id",idMercado);
        mapa.put("nombre",nombreMercado);
        mapa.put("ubicacion",ubiMercado);
        mapa.put("inicio",inicioMercado);
        mapa.put("fin",finMercado);

        firestore.collection("mercado").document(idMercado).set(mapa).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                finish();
                Toast.makeText(MainActivity.this,"Se ha añadido un mercadp",Toast.LENGTH_LONG).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this,"Error al agregar un mercado",Toast.LENGTH_LONG).show();
            }
        });
    }

    public void cerrarSesion(View view){
        auth.signOut();
        finish();
        startActivity(new Intent(MainActivity.this,InicioSesion.class));
    }
}
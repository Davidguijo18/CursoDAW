import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Zona } from '../Modelos/zona';
import { environment } from '../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class ZonasService {
  private url:string = environment.url;

  constructor(private http:HttpClient) {}

  listarZonas(){
     let pa = JSON.stringify({
        accion:"ListarZonas"
      })
      return this.http.post<Zona[]>(this.url,pa);
  }

  modificarZona(zonaObj:Zona){
    let pa = JSON.stringify({
      accion:"ModificaZona",
      zona:zonaObj
    })
    return this.http.post<Zona[]>(this.url,pa);
  }

  anadirZona(zonaObj:Zona){
    let pa = JSON.stringify({
      accion:"AnadeZona",
      zona:zonaObj
    })
    return this.http.post<Zona>(this.url,pa);
  }

  eliminarZona(idZona:number){
    let pa = JSON.stringify({
      accion:"BorrarZona",
      id:idZona
    })
    return this.http.post<Zona[]>(this.url,pa);
  }
}

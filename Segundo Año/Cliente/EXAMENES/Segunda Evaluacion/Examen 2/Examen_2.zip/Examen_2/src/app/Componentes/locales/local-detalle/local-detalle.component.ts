import { Component } from '@angular/core';
import { Local } from '../../../Modelos/local';
import { LocalesService } from '../../../Servicios/locales.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { RouterLink } from '@angular/router';
import { CartasListComponent } from "../../cartas/cartas-list/cartas-list.component";

@Component({
  selector: 'app-local-detalle',
  imports: [RouterLink, CartasListComponent],
  templateUrl: './local-detalle.component.html',
  styleUrl: './local-detalle.component.css'
})
export class LocalDetalleComponent {
  public local:Local = <Local>{};
  

  constructor(private peticion:LocalesService, private ruta:Router, private route:ActivatedRoute){
    const idLocal = this.route.snapshot.params["idLocal"];
    this.local.id = idLocal;
  }

  ngOnInit(){
    this.obtenerLocal();
    this.obtenerCartasLocal();
  }

  obtenerLocal(){
    this.peticion.obtenerLocalID(this.local.id).subscribe({
      next: res=>{
        console.log("Local obtenido: ",res);
        this.local = res;
      }
    })
  }

  eliminarLocal(local:Local){
    if(confirm("¿Desea eliminar el local " + local.nombre + " ?")){
      if(local.carta.length > 0){
        alert("No puede eliminar un local que tenga carta");
      }else{
        this.peticion.eliminarLocal(local.id).subscribe({
          next:res=>{
            console.log("Se ha eliminado el local: ",res)
            this.ruta.navigate([""]);
          },
          error: error=>{console.log("Error al eliminar el local: ",error)}
        })
      }
    }
  }

  obtenerCartasLocal(){
    const idLocal = this.route.snapshot.params["idLocal"];
    this.peticion.obtenerCartaIdLocal(idLocal).subscribe({
      next: res=>{
        console.log("Cartas obtenidas: ",res);
        this.local.carta = res;
      },
      error: error =>{console.log("Error al obtener las cartas: ",error)}
    })
  }

  borrarCarta(idCarta:number){
    console.log(`Carta con ID ${idCarta} eliminada`);
    this.local.carta = this.local.carta.filter(carta => carta.id !== idCarta);
  }
}

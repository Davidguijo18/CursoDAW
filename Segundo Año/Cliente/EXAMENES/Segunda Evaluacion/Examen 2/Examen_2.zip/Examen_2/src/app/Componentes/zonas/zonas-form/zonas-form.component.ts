import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ZonasService } from '../../../Servicios/zonas.service';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Zona } from '../../../Modelos/zona';

@Component({
  selector: 'app-zonas-form',
  imports: [ReactiveFormsModule],
  templateUrl: './zonas-form.component.html',
  styleUrl: './zonas-form.component.css'
})
export class ZonasFormComponent {
  public form:FormGroup;
  @Output() onNew = new EventEmitter<Zona>();

  constructor(private peticion:ZonasService, private fb:FormBuilder){
      this.form = this.fb.group({
        id:this.fb.control('-1'),
        nombre: this.fb.control('',[Validators.required, Validators.minLength(4)]),
      });
    }

  anadirZona(){
    this.peticion.anadirZona(this.form.value).subscribe({
      next:res=>{
        this.onNew.emit(res);
      },
      error: error=>{console.log("Error al añadir una nueva zona: ",error)}
    })
  }  
}

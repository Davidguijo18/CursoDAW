import { Component } from '@angular/core';

@Component({
  selector: 'app-cartas-form',
  imports: [],
  templateUrl: './cartas-form.component.html',
  styleUrl: './cartas-form.component.css'
})
export class CartasFormComponent {

}

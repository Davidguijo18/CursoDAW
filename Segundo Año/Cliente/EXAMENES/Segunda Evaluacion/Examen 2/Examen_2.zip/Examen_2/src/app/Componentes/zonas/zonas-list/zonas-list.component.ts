import { Component } from '@angular/core';
import { Zona } from '../../../Modelos/zona';
import { ZonasService } from '../../../Servicios/zonas.service';
import { ElementRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ZonasFormComponent } from "../zonas-form/zonas-form.component";
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-zonas-list',
  imports: [FormsModule, ZonasFormComponent,RouterLink],
  templateUrl: './zonas-list.component.html',
  styleUrl: './zonas-list.component.css'
})
export class ZonasListComponent {
  public listaZonas:Zona[] = [];
  public is_insert:boolean = false;
  public current_edit:{
    zona:Zona,
    input:any
  };
  public selId = -1;

  constructor(private peticion:ZonasService, private elRef:ElementRef){
    this.listaZonas = <Zona[]>[];
    this.current_edit = {zona:<Zona>{}, input:null};
  }

  ngOnInit(){
    this.peticion.listarZonas().subscribe({
      next: res => this.listaZonas = res,
      error: error => {console.log ("Error al listar las zonas: ",error)}
    })
  }

  showAddZonaComponent(){
    this.is_insert = !this.is_insert;
  }

  onNewZona(nuevaZona:Zona){
    this.listaZonas.push(nuevaZona);
    this.showAddZonaComponent();
  }

  editando(id:number){
    return (id == this.selId);
  }

  editZona(zona:Zona, name:HTMLInputElement, nameId:number){
    if(this.selId == -1){
      this.selId = nameId;
      this.current_edit.zona = JSON.parse(JSON.stringify(zona));
      this.current_edit.input = name;
      this.elRef.nativeElement = name;
      this.elRef.nativeElement.focus();
    }else{
      if(zona.id == this.current_edit.zona.id){
        this.selId = -1;
        zona.nombre = this.current_edit.zona.nombre;
      }else{
        this.elRef.nativeElement = this.current_edit.input;
        this.elRef.nativeElement,focus();
      }
    }
  }

  updateZona(zona:Zona){
    this.peticion.modificarZona(zona).subscribe({
      next: res =>{
        console.log("Zona modificada: ",res);
        this.selId = -1;
      },
      error: error=>{console.log("Error al modificar la zona: ",error)}
    })
  }

  deleteZona(zona:Zona){
    let mensaje = "¿Deseas eliminar la zona " + zona.nombre + " ?";
    if(confirm(mensaje)){
      this.peticion.eliminarZona(zona.id).subscribe({
        next: res=>{
          this.listaZonas = this.listaZonas.filter(tipo => tipo.id != zona.id);
          console.log("Se ha eliminado la zona: ",res);
        },
        error: error =>{console.log("Error al eliminar la zona: ",error)}
      })
    } 
  }
}

export interface Carta {
    id:number,
    id_local:number,
    descripcion:string,
    tipo:string,
    precio:number
}

import { Component } from '@angular/core';
import { Local } from '../../../Modelos/local';
import { LocalesService } from '../../../Servicios/locales.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ZonasService } from '../../../Servicios/zonas.service';
import { Zona } from '../../../Modelos/zona';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-locales-list',
  imports: [RouterLink],
  templateUrl: './locales-list.component.html',
  styleUrl: './locales-list.component.css'
})
export class LocalesListComponent {
  public listaLocales:Local[] = [];
  public listaZonas:Zona[] = [];

  constructor(private peticion:LocalesService, private ruta:Router, private route:ActivatedRoute){}

  ngOnInit(){
    this.listarLocales();
  }

  listarLocales(){
    this.peticion.listarLocales().subscribe({
      next: res=>{
        console.log("Listado de locales: ",res);
        this.listaLocales = res;
      },
      error: error=>{console.log("Error al listar los locales: ",error)}
    })
  }

  anadirLocal(){
    this.ruta.navigate(["localesForm",-1]);
  }
}

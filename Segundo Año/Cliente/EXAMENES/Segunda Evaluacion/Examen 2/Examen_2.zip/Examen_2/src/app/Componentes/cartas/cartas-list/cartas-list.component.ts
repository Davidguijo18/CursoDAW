import { Component } from '@angular/core';
import { Carta } from '../../../Modelos/carta';
import { Input } from '@angular/core';
import { CartasService } from '../../../Servicios/cartas.service';
import { CurrencyPipe } from '@angular/common';
import { Router } from '@angular/router';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-cartas-list',
  imports: [CurrencyPipe],
  templateUrl: './cartas-list.component.html',
  styleUrl: './cartas-list.component.css'
})
export class CartasListComponent {
  @Input() cartas:Carta[] = [];
  @Input() idLocal:number = 0;
  @Output() eliminaCarta = new EventEmitter<number>();

  constructor(private peticion:CartasService, private ruta:Router){}

  ngOnInit(){}

  eliminarCarta(idCarta:number,descripcion:string){
    if(confirm("¿Desea eliminar la carta con descripcion " + descripcion + " ?")){
      this.peticion.eliminarCarta(idCarta).subscribe({
        next:res=>{
          console.log("Carta eliminada correctamente");
          this.cartas = res
          this.eliminaCarta.emit(idCarta);
        },
        error: error=>{console.log("Error al eliminar la carta: ",error)}
      })
    }
  }
}

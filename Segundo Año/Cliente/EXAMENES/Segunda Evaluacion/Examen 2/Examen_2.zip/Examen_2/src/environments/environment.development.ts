export const environment = {
    url:"http://localhost/serviciosWeb/ocio/servicios.php",
};

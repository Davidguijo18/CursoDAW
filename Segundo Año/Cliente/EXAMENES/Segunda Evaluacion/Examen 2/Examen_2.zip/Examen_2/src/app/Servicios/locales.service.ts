import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Local } from '../Modelos/local';
import { Carta } from '../Modelos/carta';

@Injectable({
  providedIn: 'root'
})
export class LocalesService {
  private url:string = environment.url;

  constructor(private http:HttpClient) {}

  listarLocales(){
    let pa = JSON.stringify({
      accion:"ListarLocales"
    })
    return this.http.post<Local[]>(this.url,pa);
  }

  obtenerLocalID(idLocal:number){
    let pa =JSON.stringify({
      accion:"ObtenerLocalId",
      id:idLocal
    })
    return this.http.post<Local>(this.url,pa);
  }

  anadirLocal(localObjeto:Local){
    let pa = JSON.stringify({
      accion:"AnadeLocal",
      local: localObjeto
    })
    return this.http.post<Local[]>(this.url,pa);
  }

  eliminarLocal(idLocal:number){
    let pa = JSON.stringify({
      accion:"BorrarLocal",
      id:idLocal
    })
    return this.http.post<Local[]>(this.url,pa);
  }

  editarLocal(localObjeto:Local,idLocal:number){
    let objeto = {
      nombre:localObjeto.nombre,
      id_zona:localObjeto.id_zona, 
      telefono:localObjeto.telefono,
      direccion:localObjeto.direccion,
      observaciones:localObjeto.observaciones,
      id:idLocal
    }

   let pa=JSON.stringify({
    accion:"ModificaLocal",
    local:objeto
   })

   return this.http.post<Local[]>(this.url,pa);
  }

  obtenerCartaIdLocal(idLocal:number){
    let pa = JSON.stringify({
      accion:"ObtenerCartaIdLocal",
      id:idLocal
    })
    return this.http.post<Carta[]>(this.url,pa);
  }
}

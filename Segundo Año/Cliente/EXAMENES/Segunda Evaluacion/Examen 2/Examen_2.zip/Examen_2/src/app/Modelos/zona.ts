export interface Zona {
    id:number,
    nombre:string
}

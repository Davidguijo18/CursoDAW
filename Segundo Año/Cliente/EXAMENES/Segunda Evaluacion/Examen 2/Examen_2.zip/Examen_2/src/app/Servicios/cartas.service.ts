import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Carta } from '../Modelos/carta';

@Injectable({
  providedIn: 'root'
})
export class CartasService {
    private url:string = environment.url;

  constructor(private http:HttpClient) { }

  eliminarCarta(idCarta:number){
    let pa=JSON.stringify({
      accion:"BorrarLiniaCarta",
      id:idCarta
    });
    return this.http.post<Carta[]>(this.url,pa);
  }

  anadirCarta(){}

  modificarCarta(){}
}

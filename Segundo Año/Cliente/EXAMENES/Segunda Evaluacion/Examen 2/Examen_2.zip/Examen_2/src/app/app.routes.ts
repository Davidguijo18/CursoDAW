import { Routes } from '@angular/router';
import { LocalesListComponent } from './Componentes/locales/locales-list/locales-list.component';
import { LocalesFormComponent } from './Componentes/locales/locales-form/locales-form.component';
import { LocalDetalleComponent } from './Componentes/locales/local-detalle/local-detalle.component';
import { ZonasListComponent } from './Componentes/zonas/zonas-list/zonas-list.component';
import { CartasFormComponent } from './Componentes/cartas/cartas-form/cartas-form.component';

export const routes: Routes = [
    {
        path:"",
        component:LocalesListComponent
    },
    {
        path:"localDetail/:idLocal",
        component:LocalDetalleComponent
    },
    {
        path:"localesForm/:idLocal",
        component:LocalesFormComponent
    },
    {
        path:"listaZonas",
        component:ZonasListComponent
    },
    {
        path:"formAnadirCarta/:idCarta",
        component:CartasFormComponent
    }
];

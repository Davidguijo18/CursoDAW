import { Component } from '@angular/core';
import { Local } from '../../../Modelos/local';
import { LocalesService } from '../../../Servicios/locales.service';
import { FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { Zona } from '../../../Modelos/zona';
import { ZonasService } from '../../../Servicios/zonas.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-locales-form',
  imports: [ReactiveFormsModule],
  templateUrl: './locales-form.component.html',
  styleUrl: './locales-form.component.css'
})
export class LocalesFormComponent {
  public listaZonas:Zona[] = [];
  public local:Local = <Local>{}
  public textoH4:string = "Añadir"
  public textoP:string = "Añadir un local";
  public textoBoton:string = "Añadir";
  public form:FormGroup;
  public idVolver = 0;
  
  constructor(private peticion:LocalesService,private peticion2:ZonasService, private fb:FormBuilder,private ruta:Router, private route:ActivatedRoute){
    this.form = this.fb.group({
      id:this.fb.control('-1'),
      nombre: this.fb.control('',[Validators.required, Validators.minLength(2)]),
      id_zona: this.fb.control('',[Validators.required]),
      telefono: this.fb.control('',[Validators.required, Validators.minLength(9), Validators.maxLength(9)]),
      direccion: this.fb.control('',[Validators.required, Validators.minLength(6)]),
      observaciones: this.fb.control('',[Validators.required, Validators.minLength(12)]),
    });
  }

  ngOnInit(){
    const idLocal = this.route.snapshot.params["idLocal"];
    this.idVolver = idLocal;
    console.log("ID del local obtenido: ",idLocal);
    this.listarZonas();

    if(idLocal == -1){
      this.textoH4 = "Añadir"
      this.textoP = "Añadir un local";
      this.textoBoton = "Añadir";
    }else{
      this.textoH4 = "Editar"
      this.textoP = "Modificar un local";
      this.textoBoton = "Modificar";
      this.local.id = idLocal;

      this.peticion.obtenerLocalID(this.local.id).subscribe({
        next: res=>{
          console.log("Local obtenido: ",res);
          this.form.patchValue(res);
        }
      })
    }
  }


  listarZonas(){
    this.peticion2.listarZonas().subscribe({
      next: res=>{
        console.log("Listado de zonas: ",res);
        this.listaZonas = res;
      },
      error: error=>{console.log("Error al listar las zonas: ",error)}
    })
  }

  anadir(){
      const idLocal = this.route.snapshot.params["idLocal"];
      console.log("Datos del formulario: ",this.form.value);

      if(idLocal == -1){
        this.peticion.anadirLocal(this.form.value).subscribe({
          next: res =>{
            console.log("Se ha añadido el local", res);
            this.ruta.navigate([""]);
          },
          error: error=>console.log("Error al añadir el local: ",error)
        });
      }else{
        this.peticion.editarLocal(this.form.value,idLocal).subscribe({
          next: res =>{
            console.log("Se ha modificado el local", res);
            this.ruta.navigate(["localDetail",idLocal]);
          },
          error: error=>console.log("Error al modificar el local: ",error)
        });
      }
  }

  viajarListadoCartas(){
    this.ruta.navigate(["listaZonas"]);
  }

  volverFormulario(){
    const idLocal = this.route.snapshot.params["idLocal"];
    if(idLocal == -1){
      this.ruta.navigate([""]);
    }else{
      this.ruta.navigate(["localDetail",idLocal])
    }
  }
}

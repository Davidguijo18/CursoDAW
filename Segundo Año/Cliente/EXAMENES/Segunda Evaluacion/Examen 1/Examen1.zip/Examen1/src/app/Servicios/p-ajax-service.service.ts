import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Factura } from '../Modelos/factura';
import { DetalleFactura } from '../Modelos/detalle-factura';

@Injectable({
  providedIn: 'root'
})
export class PAjaxServiceService {
  private url:string = "http://localhost/serviciosWeb/facturas/servidor.php";

  constructor(private http:HttpClient) {}

  listarFacturas(){
    let pa = JSON.stringify({
      servicio:"facturas"
    })
    return this.http.post<Factura[]>(this.url,pa);
  }

  listarDetallesFactura(idFactura:number){
    let pa = JSON.stringify({
      servicio:"detalle",
      id:idFactura
    })

    return this.http.post<DetalleFactura[]>(this.url,pa);
  }

  borrarDetalleFactura(idDetalle:number,idFactura:number){
    let pa = JSON.stringify({
      servicio:"borra",
      id:idDetalle,
      id_factura:idFactura
    })
    
    return this.http.post<DetalleFactura[]>(this.url,pa);
  }

  anadirDetalleFactura(detalleF:DetalleFactura,){
    let pa = JSON.stringify({
      servicio:"anade",
      detalle:detalleF,
      id_factura:detalleF.id_factura
    })

    return this.http.post<DetalleFactura[]>(this.url,pa);
  }

  modificarDetalleFactura(detalleF:DetalleFactura){
    let pa = JSON.stringify({
      servicio:"modifica",
      detalle:detalleF,
      id_factura:detalleF.id_factura
    })

    return this.http.post<DetalleFactura[]>(this.url,pa);
  }
}

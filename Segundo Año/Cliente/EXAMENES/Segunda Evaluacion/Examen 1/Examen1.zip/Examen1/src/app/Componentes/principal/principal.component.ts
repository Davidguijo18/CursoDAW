import { Component, Pipe } from '@angular/core';
import { PAjaxServiceService } from '../../Servicios/p-ajax-service.service';
import { Factura } from '../../Modelos/factura';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { DecimalPipe,DatePipe } from '@angular/common';

@Component({
  selector: 'app-principal',
  imports: [FormsModule,RouterLink,DecimalPipe,DatePipe],
  templateUrl: './principal.component.html',
  styleUrl: './principal.component.css'
})
export class PrincipalComponent {
  public listaFacturas:Factura[] = [];

  constructor(private peticion:PAjaxServiceService, private ruta:Router){}

  ngOnInit(){
    this.peticion.listarFacturas().subscribe({
      next: res=>{
        this.listaFacturas = res
      },
      error: error=> console.log("Error al listar las facturas: ",error)
    })
  }
}

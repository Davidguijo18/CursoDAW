import { Component } from '@angular/core';
import { DetalleFactura } from '../../Modelos/detalle-factura';
import { PAjaxServiceService } from '../../Servicios/p-ajax-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-lista-detalle',
  standalone: false,
  
  templateUrl: './lista-detalle.component.html',
  styleUrl: './lista-detalle.component.css'
})
export class ListaDetalleComponent {
  public listaDetalles:DetalleFactura[] = [];
  public detalleFactura:DetalleFactura = <DetalleFactura>{};
  public idFactura:number = 0;
  public numeroFactura:number = 0;
  public totalTotal:number = 0;
  public totalIva:number = 0;
  public mostrarForm:boolean = false;
  public esAnadir:boolean = false;

  constructor(private peticion:PAjaxServiceService, private ruta:Router, private route:ActivatedRoute){
    this.idFactura = this.route.snapshot.params["idFactura"];
    this.numeroFactura = this.route.snapshot.params["numeroFactura"];
  }

  ngOnInit(){this.listarDetallesFactura()}

  volverAlComponentePrincipal(){this.ruta.navigate([""])}

  ocultarFormulario(){this.mostrarForm = false; this.limpiarFormulario()}

  mostrarFormulario(){
    if(this.mostrarForm)
      this.mostrarForm = false;
    else
      this.mostrarForm = true;
  }

  limpiarFormulario(){
    this.detalleFactura.cantidad = 0;
    this.detalleFactura.concepto = "";
    this.detalleFactura.precio = 0;
    this.detalleFactura.tipo_iva = 0;
  }

  listarDetallesFactura(){
    console.log("Estoy en la factura ",this.numeroFactura, " con ID: ",this.idFactura);

    this.peticion.listarDetallesFactura(this.idFactura).subscribe({
      next: res=>{
        this.listaDetalles = res

        for(var i = 0; i < res.length; i++){
          this.listaDetalles[i].iva = (res[i].precio * res[i].cantidad) * (res[i].tipo_iva / 100);
          this.totalIva += this.listaDetalles[i].iva;

          this.listaDetalles[i].total = ((res[i].precio * res[i].cantidad) + (res[i].precio * res[i].cantidad) * (res[i].tipo_iva / 100));
          this.totalTotal += this.listaDetalles[i].total;
        }
      },
      error: error =>{console.log("Error al obtener el listado de detalles de las facturas: ",error)}
    })
  }

  borrarDetalle(detalle:DetalleFactura){
    if(confirm("¿Desea eliminar el detalle con concepto: " + detalle.concepto + " ?")){
      this.peticion.borrarDetalleFactura(detalle.id,detalle.id_factura).subscribe({
        next: res =>{
          this.listaDetalles = res
          this.listarDetallesFactura();
        },
        error: error =>{console.log("Error al eliminar el detalle de factura: ",error)}
      })
    }
  }

  //No me ha dado tiempo a completar el modificar
  enviar(){
    this.anadirDetalle();
  }   

  anadirDetalle(){
    this.detalleFactura.id_factura = this.idFactura;
    this.peticion.anadirDetalleFactura(this.detalleFactura).subscribe({
      next: res =>{
        this.listaDetalles = res
        this.listarDetallesFactura();
        console.log("Se ha añadido el detalle de factura");
      },
      error: error =>{console.log("Error al añadir un nuevo detalle de factura: ",error)}
    })
    this.limpiarFormulario();
    this.ocultarFormulario();
  }

  modificarDetalle(){
    this.detalleFactura.id_factura = this.idFactura;
    this.peticion.modificarDetalleFactura(this.detalleFactura).subscribe({
      next: res =>{
        this.listaDetalles = res
        this.listarDetallesFactura();
        console.log("Se ha editado el detalle de factura");
      },
      error: error =>{console.log("Error al editar el detalle de factura: ",error)}
    })
    this.ocultarFormulario();
  } 
}